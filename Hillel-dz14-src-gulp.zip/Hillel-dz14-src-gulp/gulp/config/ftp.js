export let configFTP = {
    host: "",
    user: "",
    password: "",
    parallel: 5
}